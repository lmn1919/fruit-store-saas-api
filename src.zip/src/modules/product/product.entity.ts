import { ApiProperty } from '@nestjs/swagger';
import {
  Column,
  Entity,
  ManyToOne
} from 'typeorm';
import { ProductCategoryEntity } from '../product-category/product-category.entity';

@Entity()
export class ProductEntity {


  @ApiProperty({ description: '名称' })
  @Column({ length: 200 })
  name: string;

  @ApiProperty({ description: '图片' })
  @Column({ length: 255 })
  pic: string;

  @ApiProperty({ description: '品牌 id' })
  @Column({ type: 'bigint', name: 'brand_id' })
  brandId: number;

  @ApiProperty({ description: '品牌名称' })
  @Column({ length: 255, name: 'brand_name' })
  brandName: string;

  @ApiProperty({ description: '类别 id' })
  @Column({ type: 'bigint', name: 'product_category_id' })
  productCategoryId: number;

  @ApiProperty({ description: '商品分类名称' })
  @Column({ length: 255, name: 'product_category_name' })
  productCategoryName: string;

  @ApiProperty({ description: '详情' })
  @Column({ type: 'text', name: 'detail' })
  detail: string;

  @ApiProperty({ description: '销量' })
  sale: number;

  @ApiProperty({ description: '排序' })
  @Column({})
  sort: number;

  @ApiProperty({ description: '销售价格' })
  @Column({ type: 'decimal' })
  price: number;

  @ApiProperty({ description: '促销价格' })
  @Column({ type: 'decimal', name: 'promotion_price' })
  promotionPrice: number;

  @ApiProperty({ description: '市场价，划线价' })
  @Column({ type: 'decimal', name: 'original_price' })
  originalPrice: number;

  @ApiProperty({ description: '库存' })
  @Column({ type: 'int' })
  stock: number;

  @ApiProperty({ description: '库存预警值' })
  @Column({ type: 'int', name: 'low_stock' })
  lowStock: number;

  @ApiProperty({ description: '单位' })
  @Column({ length: 16 })
  unit: string;

  @ApiProperty({ description: '商品重量，默认为克' })
  @Column({ type: 'decimal' })
  weight: number;

  @ApiProperty({ description: '产品编码' })
  @Column({ length: 64, name: 'product_sn' })
  productSn: string;

  @ApiProperty({ description: '状态：0->草稿；1->待审核；2->上架中；3->已下架' })
  @Column({ type: 'int', name: 'status' })
  status: number;

  @ManyToOne(() => ProductCategoryEntity, (category) => category.products)
  category: ProductCategoryEntity;
}
