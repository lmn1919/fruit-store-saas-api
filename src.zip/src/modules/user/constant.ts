export enum UserStatus {
  Disable = 0,
  Enabled = 1,
}
